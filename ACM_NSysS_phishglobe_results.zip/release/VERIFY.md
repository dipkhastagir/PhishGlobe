# Verifying PHISH-GLOBE splits

record_sha256 = SHA-256 of the record's text (UTF-8), after header scrubbing.
split hash    = SHA-256 of the sorted record hashes joined with '\n'.

```python
import hashlib, pandas as pd
d = pd.read_csv('PHISHGLOBE_TEST.csv', keep_default_na=False)
h = [hashlib.sha256(t.encode('utf-8')).hexdigest() for t in d['text']]
assert h == list(d['record_sha256'])
print(hashlib.sha256('\n'.join(sorted(h)).encode('utf-8')).hexdigest())
```

Expected split hashes:

- train (n=12016): `f3065f4c2354213e7a50cf5ab33b392661c019d0303151d71e675ce0160d5b7f`
- val (n=1768): `9d1459f09fc925ca5c3873db5ede673f253f3a03d575fae4ed512f4545b09f98`
- test (n=3701): `fd9acbc5344594939e32080ba3139ea6d398d4054651f976f7fefa34f617f054`
- llm_external (n=2500): `29c8b1e3109bcf5c2da328a9a94a4f1fd2475a85820d54e1c93612244ca9fe18`
- llm_pool (n=1292): `4a9be8eef41b6853c7ff0491c6060211efa4bad9e460ba327e252cec1fead1b2`
- llm_hold (n=1208): `d1d184c506b7fa186102fa90b1edbcea65054ef70f94b9c638499ab48de4a566`
- llm_unattributed (n=1161): `bf4f160d4f329ab7caf9e801bad169643d32a01d1a2e22d065cc4199354b13bc`
